<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Puskesmas Kecamatan Kelapa Gading</title>

        <link rel="icon" href="<?php echo e(URL::asset('images/logo/logo-pks-kelapa-gading.png')); ?>" type="icon" sizes="16x16">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

        <!-- Styles -->
        

        <!-- Bootstrap 5 -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
         
        <style>
            body {
                font-family: 'Poppins', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">
            
            <?php if(Route::has('IsLogged')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 underline">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            
            <nav class="desktop-nav">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="nav-desktop">
                                <div class="nav-desktop__left">
                                    <img src="<?php echo e(URL::asset('images/logo/logo-pks-kelapa-gading.png')); ?>" alt="Logo Puskesmas Kelapa Gading">
                                    PKC Kelapa Gading
                                </div>
                                <div class="nav-desktop__right">
                                    <div class="nav-desktop__right__menu">
                                        <button class="nav-desktop__rightmenu goToTop">
                                            <div class="nav-desktop__right__menu__text">
                                                Beranda
                                            </div>
                                            <div class="nav-desktop__right__menu__lines">
                                                <div class="nav-desktop__right__menu__line"></div>
                                            </div>
                                        </button>
                                        <button class="nav-desktop__rightmenu gotoRegister">
                                            <div class="nav-desktop__right__menu__text">
                                                Daftar Vaksinasi
                                            </div>
                                            <div class="nav-desktop__right__menu__lines">
                                                <div class="nav-desktop__right__menu__line"></div>
                                            </div>
                                        </button>
                                        <button class="nav-desktop__rightmenu gotoSchedule">
                                            <div class="nav-desktop__right__menu__text">
                                                Jadwal & Lokasi Vaksinasi
                                            </div>
                                            <div class="nav-desktop__right__menu__lines">
                                                <div class="nav-desktop__right__menu__line"></div>
                                            </div>
                                        </button>
                                    </div>
                                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">Cek Hasil Swab</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>

            
            <nav class="mobile-nav">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mobile-nav__wrapper">
                                <div class="mobile-nav__left">
                                    <img src="<?php echo e(URL::asset('images/logo/logo-pks-kelapa-gading.png')); ?>" alt="Logo Puskesmas Kelapa Gading">
                                    PKC Kelapa Gading
                                </div>
                                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">Cek Hasil Swab</button>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>

            
            <div class="menubar-wrapper">
                <nav id="menubar">
                    <div class="menubar__menu gotoRegister">
                        Daftar Vaksinasi
                        <div class="menubar__menu__icon">
                            <img src="<?php echo e(URL::asset('images/icon/icon-arrow.png')); ?>">
                        </div>
                    </div>
                    <div class="menubar__separator"></div>
                    <div class="menubar__menu gotoSchedule">
                        Lokasi Vaksinasi
                        <div class="menubar__menu__icon">
                            <img src="<?php echo e(URL::asset('images/icon/icon-arrow.png')); ?>">
                        </div>
                    </div>
                </nav>
            </div>

            
            <header>
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 header__left">
                            <div class="header-banner">
                                <span>Info</span>
                                Kini warga usia 18 tahun ke atas bisa mengikuti vaksinasi
                            </div>
                            <h1>
                                Daftar Program Vaksinasi Sekarang
                            </h1>
                            <p>
                                Pelaksanaan vaksinasi COVID-19 bertujuan untuk memutus rantai penularan penyakit dan menghentikan wabah COVID-19. Vaksin COVID-19 bermanfaat untuk memberi perlindungan tubuh agar tidak jatuh sakit akibat COVID-19 dengan cara menimbulkan atau menstimulasi kekebalan spesifik dalam tubuh dengan pemberian vaksin.
                            </p>
                            <button class="btn btn-primary gotoRegister">Lihat Syarat Vaksinasi & Daftar</button>
                        </div>
                        <div class="col-md-6">
                            <div class="header-right">
                                <img src="<?php echo e(URL::asset('images/illustration/pkc-vaccine.png')); ?>" alt="daftar vaksin puskesmas kelapa gading">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-illustration">
                    <img src="<?php echo e(URL::asset('images/illustration/header-illustration.png')); ?>" alt="daftar vaksin puskesmas kelapa gading">
                </div>
            </header>

            <div class="info">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="big-menu-title">
                                <div class="icon icon-secondary">
                                    <img src="<?php echo e(URL::asset('images/icon/icon-info.png')); ?>" alt="info vaksin puskesmas kelapa gading">
                                </div>
                                <div class="menu-title">
                                    Pengumuman dosis kedua vaksin COVID-19 untuk 18+
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <p>
                                Untuk dosis 2 vaksin COVID-19 bagi 18+, tidak dilakukan penjadwalan melalui website. Anda bisa datang sesuai lokasi dan waktu yang telah ditentukan oleh petugas di lokasi vaksinasi dosis 1.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div id="home-register" class="register">
                    <div class="ornamen">
                        <img src="<?php echo e(URL::asset('images/illustration/backdrop-register.png')); ?>">
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-5">
                                <div class=" register-img">
                                    <img src="<?php echo e(URL::asset('images/illustration/vaccine-register-illustration.png')); ?>" alt="jadwal vaksin puskesmas kelapa gading">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="big-menu-title mb-4">
                                    <div class="icon icon-primary">
                                        <img src="<?php echo e(URL::asset('images/icon/icon-register.png')); ?>" alt="daftar vaksin puskesmas kelapa gading">
                                    </div>
                                    <div class="menu-title">
                                        Pendaftaran Vaksin Covid-19 untuk Pra Lansia
                                    </div>
                                </div>
                                <p>
                                    Silahkan mendaftar untuk mendapatkan vaksinasi COVID-19 yang KTP atau bertempat tinggal di wilayah DKI Jakarta
                                </p>
                                <div class="submenu mb-2">
                                    Syarat Pendaftaran Vaksin Covid-19 untuk Pra Lansia:
                                </div>
                                <ol class="mb-4">
                                    <li>Usia >18 tahun atau sudah berulang tahun ke-18 saat pengisian formulir</li>
                                    <li>Usia >50 - 59 tahun untuk kategori pra lansia</li>
                                    <li>Usia >60 tahun untuk kategori lansia</li>
                                    <li>WNI yang memiliki KTP DKI atau domisili dari Kelurahan setempat di wilayah DKI Jakarta</li>
                                    <li>Saat vaksinasi, membawa fotokopi KTP dan KK, memakai masker dan menerapkan protokol kesehatan COVID-19</li>
                                    <li>Validasi persyaratan dilakukan di lokasi vaksinasi</li>
                                    <li>Nomor antrian sesuai kedatangan di lokasi vaksinasi</li>
                                    <li>Tidak terdaftar di vaksin gotong royong</li>
                                </ol>
                                <a href="" class="btn btn-primary">Daftar Vaksinasi</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="home-schedule" class="schedule">
                    <div class="ornamen">
                        <img src="<?php echo e(URL::asset('images/illustration/backdrop-schedule.png')); ?>">
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 big-menu-center">
                                <div class="big-menu-title mb-4">
                                    <div class="icon icon-primary">
                                        <img src="<?php echo e(URL::asset('images/icon/icon-schedule.png')); ?>" alt="jadwal vaksin puskesmas kelapa gading">
                                    </div>
                                    <div class="menu-title">
                                        Konfirmasi Jadwal Vaksin Covid-19 untuk Pra Lansia dan Non Lansia
                                    </div>
                                </div>
                                <p class="mb-4 desktop-center">
                                    Cek konfirmasi nama yang telah didaftarkan melalui bit.ly/vaksinpuskesmasgading untuk penerima vaksin COVID-19 dengan kriteria pra lansia atau pendamping berdasarkan pos vaksinasi yang Anda pilih saat mendaftar. Calon penerima vaksin  wajib membawa fotokopi KK dan KTP. Nomer antrian sesuai dengan kedatangan. Calon penerima vaksin akan tetap dilakukan pemeriksaan skrining dan dokumen saat pelaksanaan vaksinasi. Keputusan pemberian vaksin tetap diserahkan oleh petugas pelaksana.
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div id="home-location" class="location mt-5">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="location-detail mb-5">
                                                <div class="big-menu-title mb-4">
                                                    <div class="icon icon-primary">
                                                        <img src="<?php echo e(URL::asset('images/icon/icon-map.png')); ?>" alt="lokasi vaksi puskesmas kelapa gading">
                                                    </div>
                                                    <div class="menu-title">
                                                        Jadwal Vaksin SMP Negeri 270
                                                    </div>
                                                </div>
                                                <p>
                                                    Jl. Kompi Udin, RT.3/RW.7, Pegangsaan Dua, Kec. Klp. Gading, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14250
                                                </p>
                                                <a href="https://goo.gl/maps/Gbw6KgKrzXipz3iWA" target="_blank" class="btn btn-primary">Lihat di Peta</a>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="location-map">
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.653851411901!2d106.90932891531881!3d-6.177070962250029!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f4d4da872d27%3A0xbcdef57134c91ffd!2sSekolah%20Menengah%20Pertama%20Negeri%20270%20Jakarta%20Utara!5e0!3m2!1sen!2sid!4v1626788467262!5m2!1sen!2sid" width="100%" height="250" style="border:0; border-radius: 20px;" allowfullscreen="" loading="lazy"></iframe>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="location-schedule">
                                            <iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vTMXeVE8g0e0V8czMzCH8VUgsKKmyyAfPtzc4aafCAP_Un5JL1pBEGTSfbvexRfyylnGnltK_mHT7mN/pubhtml?widget=true&amp;headers=false"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="location mt-5">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="location-detail mb-5">
                                                <div class="big-menu-title mb-4">
                                                    <div class="icon icon-primary">
                                                        <img src="<?php echo e(URL::asset('images/icon/icon-map.png')); ?>" alt="lokasi vaksi puskesmas kelapa gading">
                                                    </div>
                                                    <div class="menu-title">
                                                        Jadwal Vaksin GOR Judo Kelapa Gading
                                                    </div>
                                                </div>
                                                <p>
                                                    Jalan Kelapa Puan Raya Blok EF 1 No.1, Kelapa Gading, RW.13, Klp. Gading Tim., Jakarta Utara, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240
                                                </p>
                                                <a href="https://goo.gl/maps/9LZEQLm78cvYT6WN8" target="_blank" class="btn btn-primary">Lihat di Peta</a>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="location-map">
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7933.419594935125!2d106.9047831!3d-6.1695999!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5321adbaff1%3A0x2e08e576e6a78587!2sGedung%20Judo!5e0!3m2!1sen!2sid!4v1626854191916!5m2!1sen!2sid" width="100%" height="250" style="border:0; border-radius: 20px;" allowfullscreen="" loading="lazy"></iframe>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="location-schedule">
                                            <iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSkBMhIs3e73HkfWKsC8qoENu4G-mLb1t2Jj2iPDMwO4lt82nE4LQfnZ6fg__uk1EBqToch3V5x_yf-/pubhtml?widget=true&amp;headers=false"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <footer>

            </footer>

            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Periksa Hasil Swab PCR</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('hasil-swab.cekswab')); ?>" method="post" enctype="multipart/form-data" id="myForm">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <div class="result">
                                        <?php if(Session::get('fail')): ?>
                                            <div class="alert alert-danger">
                                                <?php echo e(Session::get('fail')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <label for="nik" class="form-label">Nomor Induk Kependudukan (NIK)</label>
                                    
                                    
                                    <input type="text" class="form-control" id="nik" placeholder="Masukkan 16 digit NIK" name="nik" pattern="\d*" minlength="16" maxlength="16" title="Harus 16 angka" required>
                                    <span class="text-danger"><?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Lihat Hasil</button>
                        </form>
                    </div>
                </div>
                </div>
            </div>

        </div>

        <!-- jQuery 3 -->
        <script src="<?php echo e(URL::asset('js/jquery-3.6.0.js')); ?>"></script>
        <!-- Bootstrap 5 -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

        <script>
            $(document).ready(function (){
                $(".gotoRegister").click(function (){
                    $('html, body').animate({
                        scrollTop: $("#home-register").offset().top
                    }, 600);
                });

                $(".gotoSchedule").click(function (){
                    $('html, body').animate({
                        scrollTop: $("#home-schedule").offset().top
                    }, 600);
                });

                $(".goToTop").click(function (){
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                    return false;
                });

                $(".nav-desktop__rightmenu").hover(
                    function() {
                        $(this).find(".nav-desktop__right__menu__line").toggleClass("nav-hover");
                    }
                );

                // $('#cekSwab').on('shown.bs.modal', function () {
                //     $('#myInput').trigger('focus')
                //     console.log('tes');
                // })

                var load_flag = true;
                $(document).scroll(function() {
                    
                    var mywindow = $(window);
                    var mypos = mywindow.scrollTop();
                    var up = false;
                    var newscroll;
                    mywindow.scroll(function () {
                        newscroll = mywindow.scrollTop();
                        if (newscroll > mypos && !up) {
                            $('#menubar ').fadeOut();
                            up = !up;
                            console.log(up);
                        } else if(newscroll < mypos && up) {
                            $('#menubar ').fadeIn();
                            up = !up;
                        }
                        mypos = newscroll;
                    });
                });

                <?php if(Session::get('fail')): ?>
                    // <div class="alert alert-danger">
                    //     <?php echo e(Session::get('fail')); ?>

                    // </div>
                    $('#exampleModal').modal('show');
                <?php endif; ?>

                $( "#myForm" ).validate({
                    rules: {
                        field: {
                            exactlength: 16
                        }
                    }
                });

            });
        </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\puskes_gading\resources\views/welcome.blade.php ENDPATH**/ ?>